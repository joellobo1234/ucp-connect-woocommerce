### What's New
- **List All Products**: You can now pass an empty string `""` to `search_products` to retrieve the entire product catalog (paginated).
- **Backend Fix**: Resolved issue where empty searches returned nothing.

### Installation
Download the attached `ucp-connect-woocommerce-1.3.2.zip` and install/update via your WordPress Plugins dashboard.
